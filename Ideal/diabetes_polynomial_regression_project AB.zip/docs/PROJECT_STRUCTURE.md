# Project Structure — Diabetes Polynomial Regression

This document explains how the folders and files in this project map to your ML workflow.

```text
diabetes_polynomial_regression_project/
├── README.md
├── docs/
│   └── PROJECT_STRUCTURE.md
├── data/
│   └── diabetes_sample.csv
├── src/
│   ├── __init__.py
│   ├── config.py
│   ├── data_loading.py
│   ├── eda.py
│   ├── imputation.py
│   ├── features.py
│   ├── model.py
│   ├── anova_chatterjee.py
│   ├── evaluation.py
│   └── utils.py
├── scripts/
│   ├── run_eda.py
│   └── train_from_scratch.py
└── requirements.txt
```

## `data/`

- **`diabetes_sample.csv`** – synthetic diabetes-style dataset with:
  - numerical features: `age`, `bmi`, `bp`, `s1`, `s2`, `s3`, `s4`
  - target: `diabetes_progression`

Replace this file with your own diabetes dataset while keeping a numeric target column.

## `src/` — Reusable Library Code

- `config.py`  
  Central place for configuration such as:
  - `DATA_PATH`
  - target column name
  - default polynomial degree, random seeds, etc.

- `data_loading.py`  
  Functions to:
  - load the diabetes CSV into a pandas DataFrame
  - split into features/target
  - train/test split helpers

- `eda.py`  
  EDA utilities:
  - distribution plots (histogram + KDE)
  - boxplots
  - violin plots
  - outlier detection using IQR / Z-score
  - outlier treatment (capping/winsorization)

- `imputation.py`  
  Missing value handling:
  - simple pandas-based imputation
  - Iterative Imputer
  - KNN Imputer
  - LGBM-based imputer (optional, advanced)

- `features.py`  
  Feature engineering utilities:
  - polynomial feature generation
  - utilities to keep track of feature names

- `model.py`  
  **PolynomialRegressionScratch** implementation:
  - Builds polynomial features
  - Solves Normal Equation
  - Computes log-likelihood and AIC

- `anova_chatterjee.py`  
  Statistical tools:
  - **Chatterjee correlation** implementation (nonlinear dependence)
  - **One-way ANOVA** wrapper using `scipy.stats`

- `evaluation.py`  
  Metrics and evaluation:
  - MSE, RMSE, R², Adjusted R²
  - helper to summarize metrics in a dict/printable format

- `utils.py`  
  Small shared utilities used across modules (e.g., directory creation).

## `scripts/` — Entry Points

- `run_eda.py`  
  CLI script that:
  - loads the dataset
  - runs basic EDA
  - generates distribution, boxplot, violin plots
  - saves plots to a `plots/` folder

- `train_from_scratch.py`  
  CLI training script that:
  - loads and optionally imputes the dataset
  - builds polynomial features
  - fits the custom polynomial regression model
  - prints metrics, log-likelihood, and AIC

## `requirements.txt`

Lists external Python dependencies needed to run this project
(numpy, pandas, matplotlib, seaborn, scikit-learn, scipy, lightgbm).

---

You can copy this exact project structure as a **template** for your other regression projects:
just change the dataset and update config values — the pipeline stays the same.
