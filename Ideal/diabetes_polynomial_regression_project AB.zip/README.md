 # Diabetes Polynomial Regression — From Scratch (with Advanced EDA & Imputation)

 This project builds a **Polynomial Regression model from scratch** (using the Normal Equation)
 on a **Diabetes progression dataset**, and is designed to practice **both statistics and ML engineering**.

 It combines **exploratory data analysis, outlier handling, multiple imputation strategies,
 ANOVA, Chatterjee correlation, AIC & likelihood**, and a custom polynomial regression model.

 ---

 ## 🎯 Project Outcomes

 By completing this project, you will be able to:

 ### 📊 Exploratory Data Analysis & Visualization
 - Understand and implement **distribution plots** (histograms & KDE).
 - Understand and implement **boxplots**.
 - Understand and implement **violin plots**.
 - **Detect outliers** using IQR and Z-score methods.
 - **Treat outliers** using capping / winsorization.

 ### 🧩 Missing Data & Imputation
 - Use a **pandas imputer** (`fillna`, simple strategies).
 - Use **Iterative Imputer** (multivariate imputation).
 - Use **KNN Imputer** (nearest-neighbor based imputations).
 - Use an **LGBM-based imputer** (train LightGBM models to fill missing values).

 ### 📈 Feature & Relationship Analysis
 - Run **Univariate analysis** (summary stats, skew, kurtosis, density).
 - Compute **Chatterjee correlation** to detect nonlinear dependence.
 - Understand **ANOVA** (Analysis of Variance).
 - Implement **one-way ANOVA** to test if a categorical factor affects the target.

 ### 🤖 Modeling & Model Selection
 - Perform **data preprocessing** for regression.
 - Build a **Polynomial Regression model from scratch**:
   - Create polynomial features.
   - Solve for parameters using the **Normal Equation**.
 - Understand **likelihood** for a regression model with Gaussian errors.
 - Compute **AIC (Akaike Information Criterion)** from the log-likelihood.
 - Compare polynomial degrees using **AIC** and error metrics.

 ---

 ## 🧪 Dataset

For convenience, this repo ships with a small **synthetic diabetes-style dataset**:

 - File: `data/diabetes_sample.csv`
 - Target column: `diabetes_progression`
 - Features: `age`, `bmi`, `bp`, `s1`, `s2`, `s3`, `s4`

 In a real project, you can **replace this CSV** with your own diabetes dataset
 (e.g., from research / Kaggle / hospital anonymized dataset) as long as you keep a numeric target.

 ---

 ## 🏗️ Project Structure

 ```text
 diabetes_polynomial_regression_project/
 ├── README.md
 ├── docs/
 │   └── PROJECT_STRUCTURE.md
 ├── data/
 │   └── diabetes_sample.csv
 ├── src/
 │   ├── __init__.py
 │   ├── config.py
 │   ├── data_loading.py
 │   ├── eda.py
 │   ├── imputation.py
 │   ├── features.py
 │   ├── model.py
 │   ├── anova_chatterjee.py
 │   ├── evaluation.py
 │   └── utils.py
 ├── scripts/
 │   ├── run_eda.py
 │   └── train_from_scratch.py
 └── requirements.txt
 ```

 - `src/` contains reusable, testable logic.
 - `scripts/` are CLI-style entry points that call into `src/`.
 - `data/` holds your CSVs.
 - `docs/` documents the structure (so future-you remembers the pipeline).

 ---

 ## 🚀 Quickstart

 ### 1. Create a virtual environment (optional but recommended)

 ```bash
 python -m venv .venv
 source .venv/bin/activate        # Linux / macOS
 .venv\Scripts\activate         # Windows
 ```

 ### 2. Install dependencies

 ```bash
 pip install -r requirements.txt
 ```

 > If you don't want to use LightGBM-based imputation, you can comment it out
 > in `imputation.py` and skip installing `lightgbm`.

 ### 3. Run basic EDA

 ```bash
 python scripts/run_eda.py
 ```

 This will:
 - Load `data/diabetes_sample.csv`
 - Generate distribution, boxplot and violin plots
 - Detect & treat outliers
 - Save plots to `plots/` (folder created automatically)

 ### 4. Train polynomial regression model from scratch

 ```bash
 python scripts/train_from_scratch.py --degree 2
 ```

 This will:
 - Load and optionally impute missing values.
 - Create polynomial features (up to the degree you choose).
 - Fit the regression using the **Normal Equation**.
 - Compute metrics: MSE, RMSE, R², Adjusted R², AIC, log-likelihood.
 - Print a short report in the console.

 ---

 ## 🔬 Extending This Project

 - Swap the synthetic diabetes CSV with your **real diabetes dataset**.
 - Add more **ANOVA experiments** for different categorical features.
 - Compare **multiple polynomial degrees** and rank them by AIC.
 - Log all runs to a tracking tool (MLflow / Weights & Biases).
 - Wrap `train_from_scratch.py` into a FastAPI / Flask API for inference.

 ---

 ## 💡 Why This Is a Good Direction

 - You’re not just training “yet another regression model” — you’re
   deliberately practicing **statistics, diagnostics, and ML engineering**.
 - The same structure can be **reused for your other 29 projects** with
   different datasets and goals.
 - It trains you to think like a **production ML engineer**:
   - clear project structure
   - reusable modules
   - explicit modeling assumptions (AIC, likelihood, ANOVA, correlations)
   - separation between notebooks / scripts / src code

 Happy experimenting with diabetes regression and beyond! 🧪📈
