from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

from .features import make_polynomial_features


@dataclass
class PolynomialRegressionScratch:
    """Polynomial Regression implemented from scratch using the Normal Equation."""

    degree: int = 2
    include_bias: bool = True
    l2_reg: float = 0.0  # L2 regularization term (ridge-like)

    coef_: Optional[np.ndarray] = None
    feature_names_: Optional[list] = None

    def fit(self, X, y):
        X_poly, feature_names = make_polynomial_features(
            X, degree=self.degree, include_bias=self.include_bias
        )

        # Normal Equation with optional L2 regularization: (X^T X + λI)^(-1) X^T y
        XtX = X_poly.T @ X_poly
        if self.l2_reg > 0:
            reg_matrix = self.l2_reg * np.eye(XtX.shape[0])
            XtX = XtX + reg_matrix

        Xty = X_poly.T @ y
        self.coef_ = np.linalg.inv(XtX) @ Xty
        self.feature_names_ = feature_names
        return self

    def predict(self, X) -> np.ndarray:
        if self.coef_ is None:
            raise RuntimeError("Model is not fitted yet.")
        X_poly, _ = make_polynomial_features(
            X, degree=self.degree, include_bias=self.include_bias
        )
        return X_poly @ self.coef_

    # ---------- Likelihood & AIC ----------

    def _sse_and_sigma2(self, y_true, y_pred) -> Tuple[float, float]:
        residuals = y_true - y_pred
        sse = float((residuals ** 2).sum())
        n = len(y_true)
        sigma2 = sse / n
        return sse, sigma2

    def log_likelihood(self, y_true, y_pred) -> float:
        """
        Log-likelihood under Gaussian noise assumption.

        L = ∏ (1 / sqrt(2πσ²)) * exp(-(y_i - ŷ_i)² / (2σ²))
        ln L = -n/2 * [ln(2πσ²) + 1]
        """
        n = len(y_true)
        _, sigma2 = self._sse_and_sigma2(y_true, y_pred)
        if sigma2 <= 0:
            return float("-inf")
        logL = -0.5 * n * (np.log(2 * np.pi * sigma2) + 1)
        return float(logL)

    def aic(self, y_true, y_pred) -> float:
        """Compute Akaike Information Criterion for the fitted model."""
        k = len(self.coef_)  # number of parameters
        logL = self.log_likelihood(y_true, y_pred)
        return 2 * k - 2 * logL
