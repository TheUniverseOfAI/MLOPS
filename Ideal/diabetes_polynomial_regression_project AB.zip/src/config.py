from pathlib import Path

# Base configuration values used across the project.

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "data" / "diabetes_sample.csv"

TARGET_COLUMN = "diabetes_progression"

# Default model / training configuration
DEFAULT_POLY_DEGREE = 2
TEST_SIZE = 0.2
RANDOM_STATE = 42
