from typing import Dict

import numpy as np
from sklearn.metrics import mean_squared_error, r2_score


def regression_metrics(y_true, y_pred, n_params: int) -> Dict[str, float]:
    """Compute common regression metrics + adjusted R²."""
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    mse = mean_squared_error(y_true, y_pred)
    rmse = float(mse ** 0.5)
    r2 = r2_score(y_true, y_pred)
    n = len(y_true)

    # Adjusted R^2
    adj_r2 = 1 - (1 - r2) * (n - 1) / (n - n_params - 1)

    return {
        "mse": float(mse),
        "rmse": rmse,
        "r2": float(r2),
        "adjusted_r2": float(adj_r2),
    }
