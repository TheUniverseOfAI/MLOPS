from typing import Tuple

import numpy as np
import pandas as pd
from scipy import stats


def chatterjee_correlation(x, y) -> float:
    """
    Compute Chatterjee's correlation coefficient between two 1D arrays.

    Implementation based on the definition:
    - Sort by x
    - Rank y
    - Compute T_n = (1/(n-1)) * sum |R_{i+1} - R_i|
    - Xi_n = 1 - (3 * T_n) / (n**2 - 1)
    """
    x_arr = np.asarray(x)
    y_arr = np.asarray(y)
    if x_arr.ndim != 1 or y_arr.ndim != 1:
        raise ValueError("x and y must be 1D arrays")
    if len(x_arr) != len(y_arr):
        raise ValueError("x and y must have the same length")

    # Sort by x
    order = np.argsort(x_arr)
    y_sorted = y_arr[order]

    # Rank y (average ranks for ties)
    ranks = stats.rankdata(y_sorted, method="average")

    # Compute T_n
    diff = np.abs(np.diff(ranks))
    n = len(ranks)
    if n < 2:
        return np.nan
    Tn = diff.sum() / (n - 1)

    # Chatterjee's coefficient
    denom = n ** 2 - 1
    if denom <= 0:
        return np.nan
    xi_n = 1.0 - (3.0 * Tn) / denom
    return float(xi_n)


def one_way_anova(df: pd.DataFrame, target_col: str, factor_col: str) -> Tuple[float, float]:
    """
    Run one-way ANOVA on target_col grouped by factor_col.

    Returns:
        F-statistic, p-value
    """
    groups = [
        group[target_col].dropna().values
        for _, group in df.groupby(factor_col)
    ]

    if len(groups) < 2:
        raise ValueError("ANOVA requires at least two groups.")

    F_stat, p_value = stats.f_oneway(*groups)
    return float(F_stat), float(p_value)
