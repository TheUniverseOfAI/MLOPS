from typing import Tuple

import numpy as np
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures


def make_polynomial_features(
    X, degree: int = 2, include_bias: bool = True
) -> Tuple[np.ndarray, list]:
    """
    Generate polynomial features from input X using sklearn's PolynomialFeatures.

    Returns:
        X_poly: numpy array of transformed features
        feature_names: list of feature names for the polynomial terms
    """
    if isinstance(X, pd.DataFrame):
        feature_names_input = X.columns
        X_values = X.values
    else:
        feature_names_input = None
        X_values = X

    poly = PolynomialFeatures(degree=degree, include_bias=include_bias)
    X_poly = poly.fit_transform(X_values)

    if feature_names_input is not None:
        feature_names = poly.get_feature_names_out(feature_names_input).tolist()
    else:
        feature_names = poly.get_feature_names_out().tolist()

    return X_poly, feature_names
