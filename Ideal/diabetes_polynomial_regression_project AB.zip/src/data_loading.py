from pathlib import Path
from typing import Tuple

import pandas as pd
from sklearn.model_selection import train_test_split

from .config import DATA_PATH, TARGET_COLUMN, TEST_SIZE, RANDOM_STATE


def load_diabetes(path: Path = DATA_PATH) -> pd.DataFrame:
    """Load the diabetes CSV into a pandas DataFrame."""
    return pd.read_csv(path)


def split_features_target(df: pd.DataFrame, target_column: str = TARGET_COLUMN):
    """Split DataFrame into X (features) and y (target)."""
    X = df.drop(columns=[target_column])
    y = df[target_column]
    return X, y


def train_test_split_diabetes(
    X, y, test_size: float = TEST_SIZE, random_state: int = RANDOM_STATE
) -> Tuple:
    """Train/test split helper for the diabetes dataset."""
    return train_test_split(X, y, test_size=test_size, random_state=random_state)
