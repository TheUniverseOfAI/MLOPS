import sys
from pathlib import Path

# Allow `src` imports when running as a script
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from src.config import DATA_PATH
from src.data_loading import load_diabetes
from src.eda import plot_distribution, plot_boxplot, plot_violin, detect_outliers_iqr, cap_outliers_iqr
from src.utils import ensure_dir


def main():
    df = load_diabetes(DATA_PATH)
    plots_dir = ROOT / "plots"
    ensure_dir(plots_dir)

    numeric_cols = df.select_dtypes(include=["number"]).columns

    # Distribution, box, and violin plots
    for col in numeric_cols:
        plot_distribution(df, col, save_dir=plots_dir)
        plot_boxplot(df, col, save_dir=plots_dir)
        plot_violin(df, col, save_dir=plots_dir)

    # Simple outlier detection + treatment example on each column
    for col in numeric_cols:
        mask_outliers = detect_outliers_iqr(df[col].dropna())
        n_outliers = mask_outliers.sum()
        print(f"[EDA] Column {col}: detected {n_outliers} outliers via IQR.")

        # Example of capping outliers (not writing back to df here)
        capped = cap_outliers_iqr(df[col].dropna())
        # You could save or analyze `capped` further if needed

    print(f"Saved distribution, boxplot, and violin plots to: {plots_dir}")


if __name__ == "__main__":
    main()
