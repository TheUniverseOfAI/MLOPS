import argparse
import sys
from pathlib import Path

import numpy as np

# Allow `src` imports when running as a script
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from src.config import DATA_PATH, TARGET_COLUMN, DEFAULT_POLY_DEGREE
from src.data_loading import load_diabetes, split_features_target, train_test_split_diabetes
from src.imputation import simple_pandas_imputer
from src.model import PolynomialRegressionScratch
from src.evaluation import regression_metrics


def parse_args():
    parser = argparse.ArgumentParser(description="Train Polynomial Regression from scratch on diabetes data.")
    parser.add_argument(
        "--degree",
        type=int,
        default=DEFAULT_POLY_DEGREE,
        help="Polynomial degree (default: %(default)s)",
    )
    parser.add_argument(
        "--l2_reg",
        type=float,
        default=0.0,
        help="L2 regularization term (default: 0.0)",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    # Load data
    df = load_diabetes(DATA_PATH)
    print(f"Loaded dataset from {DATA_PATH} with shape {df.shape}")

    # Simple imputation for missing values
    df_imputed = simple_pandas_imputer(df, strategy="median")

    # Split into features and target
    X, y = split_features_target(df_imputed, target_column=TARGET_COLUMN)

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split_diabetes(X, y)
    print(f"Train shape: {X_train.shape}, Test shape: {X_test.shape}")

    # Fit polynomial regression model
    model = PolynomialRegressionScratch(degree=args.degree, l2_reg=args.l2_reg)
    model.fit(X_train, y_train.values)

    # Predictions
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)

    # Metrics
    n_params = len(model.coef_)
    train_metrics = regression_metrics(y_train.values, y_train_pred, n_params=n_params)
    test_metrics = regression_metrics(y_test.values, y_test_pred, n_params=n_params)

    train_logL = model.log_likelihood(y_train.values, y_train_pred)
    test_logL = model.log_likelihood(y_test.values, y_test_pred)

    train_aic = model.aic(y_train.values, y_train_pred)
    test_aic = model.aic(y_test.values, y_test_pred)

    print("\n=== Polynomial Regression From Scratch ===")
    print(f"Degree: {args.degree}, L2 regularization: {args.l2_reg}")
    print(f"Number of parameters: {n_params}")
    print("\n--- Train Metrics ---")
    for k, v in train_metrics.items():
        print(f"{k}: {v:.4f}")
    print(f"log_likelihood: {train_logL:.4f}")
    print(f"AIC: {train_aic:.4f}")

    print("\n--- Test Metrics ---")
    for k, v in test_metrics.items():
        print(f"{k}: {v:.4f}")
    print(f"log_likelihood: {test_logL:.4f}")
    print(f"AIC: {test_aic:.4f}")

    print("\nDone.")


if __name__ == "__main__":
    main()
