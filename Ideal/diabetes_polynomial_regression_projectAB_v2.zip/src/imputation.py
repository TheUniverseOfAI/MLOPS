from typing import List, Optional

import numpy as np
import pandas as pd
from sklearn.impute import KNNImputer, IterativeImputer


def simple_pandas_imputer(df: pd.DataFrame, strategy: str = "median") -> pd.DataFrame:
    """Simple pandas-based imputation using mean/median/zero for numeric columns."""
    result = df.copy()
    num_cols = result.select_dtypes(include=["number"]).columns
    if strategy == "mean":
        fill_values = result[num_cols].mean()
    elif strategy == "median":
        fill_values = result[num_cols].median()
    elif strategy == "zero":
        fill_values = {col: 0 for col in num_cols}
    else:
        raise ValueError(f"Unsupported strategy: {strategy}")
    result[num_cols] = result[num_cols].fillna(fill_values)
    return result


def knn_imputer(df: pd.DataFrame, n_neighbors: int = 5) -> pd.DataFrame:
    """Impute numeric columns using KNNImputer."""
    num_cols = df.select_dtypes(include=["number"]).columns
    imputer = KNNImputer(n_neighbors=n_neighbors)
    imputed = imputer.fit_transform(df[num_cols])
    result = df.copy()
    result[num_cols] = imputed
    return result


def iterative_imputer(df: pd.DataFrame, random_state: int = 42) -> pd.DataFrame:
    """Impute numeric columns using IterativeImputer (multivariate imputation)."""
    num_cols = df.select_dtypes(include=["number"]).columns
    imputer = IterativeImputer(random_state=random_state)
    imputed = imputer.fit_transform(df[num_cols])
    result = df.copy()
    result[num_cols] = imputed
    return result


def lgbm_imputer(df: pd.DataFrame, columns: Optional[List[str]] = None, random_state: int = 42) -> pd.DataFrame:
    """
    Impute numeric columns using LightGBM as a predictive model per column with missing values.

    This is a simple implementation:
    - For each column with NaNs (or passed in `columns`),
      train a LightGBM regressor using other numeric columns as features.
    - Predict missing values.
    """
    try:
        from lightgbm import LGBMRegressor
    except ImportError as e:
        raise ImportError(
            "lightgbm is not installed. Install it with `pip install lightgbm` "
            "or skip using lgbm_imputer."
        ) from e

    result = df.copy()
    num_cols = result.select_dtypes(include=["number"]).columns.tolist()

    if columns is None:
        columns = [c for c in num_cols if result[c].isna().any()]

    for col in columns:
        if col not in num_cols:
            continue

        mask_missing = result[col].isna()
        if not mask_missing.any():
            continue

        feature_cols = [c for c in num_cols if c != col]
        train_data = result.loc[~mask_missing, feature_cols]
        train_target = result.loc[~mask_missing, col]

        # Skip if not enough data
        if len(train_data) < 10:
            continue

        model = LGBMRegressor(random_state=random_state)
        model.fit(train_data, train_target)

        test_data = result.loc[mask_missing, feature_cols]
        preds = model.predict(test_data)
        result.loc[mask_missing, col] = preds

    return result
