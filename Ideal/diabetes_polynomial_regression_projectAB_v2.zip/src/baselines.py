from typing import Dict

from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.tree import DecisionTreeRegressor


def get_baseline_models() -> Dict[str, object]:
    """Return a dictionary of baseline regression models to compare."""
    models = {
        "linear_regression": LinearRegression(),
        "ridge_alpha_1.0": Ridge(alpha=1.0),
        "lasso_alpha_0.1": Lasso(alpha=0.1),
        "decision_tree_depth_4": DecisionTreeRegressor(max_depth=4, random_state=42),
    }
    return models
