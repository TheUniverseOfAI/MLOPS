from pathlib import Path
from typing import List

import pandas as pd
from fastapi import FastAPI
from pydantic import BaseModel

from .config import DATA_PATH, TARGET_COLUMN
from .data_loading import load_diabetes, split_features_target
from .imputation import simple_pandas_imputer
from .model import PolynomialRegressionScratch


class DiabetesFeatures(BaseModel):
    age: float
    bmi: float
    bp: float
    s1: float
    s2: float
    s3: float
    s4: float


app = FastAPI(title="Diabetes Polynomial Regression API")

MODEL = None
FEATURE_COLUMNS: List[str] = []


@app.on_event("startup")
def load_model_on_startup():
    """Train a simple polynomial regression model at startup.

    In a more advanced version, you would load a pre-trained model from disk
    (e.g., from the `models/` folder) instead of training at startup.
    """
    global MODEL, FEATURE_COLUMNS
    df = load_diabetes(DATA_PATH)
    df_imputed = simple_pandas_imputer(df, strategy="median")
    X, y = split_features_target(df_imputed, target_column=TARGET_COLUMN)
    FEATURE_COLUMNS = list(X.columns)

    model = PolynomialRegressionScratch(degree=2, l2_reg=0.0)
    model.fit(X, y.values)
    MODEL = model


@app.get("/health")
def health_check():
    return {"status": "ok"}


@app.post("/predict")
def predict_progression(features: DiabetesFeatures):
    if MODEL is None:
        return {"error": "Model not loaded"}

    data = pd.DataFrame([[
        features.age,
        features.bmi,
        features.bp,
        features.s1,
        features.s2,
        features.s3,
        features.s4,
    ]], columns=FEATURE_COLUMNS)

    pred = MODEL.predict(data)[0]
    return {"diabetes_progression_prediction": float(pred)}
