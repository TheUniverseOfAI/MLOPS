from typing import Dict, Tuple

import numpy as np
from sklearn.model_selection import KFold, cross_val_score, GridSearchCV


def evaluate_models_cv(X, y, models: Dict[str, object], cv: int = 5) -> Dict[str, float]:
    """
    Evaluate multiple models with K-fold cross-validation (RMSE).

    Returns:
        dict of model_name -> mean_RMSE
    """
    results = {}
    for name, model in models.items():
        scores = cross_val_score(
            model,
            X,
            y,
            scoring="neg_mean_squared_error",
            cv=cv,
            n_jobs=-1,
        )
        rmse_scores = np.sqrt(-scores)
        results[name] = float(rmse_scores.mean())
    return results


def grid_search_model(
    model,
    param_grid: Dict,
    X,
    y,
    cv: int = 5,
    scoring: str = "neg_mean_squared_error",
) -> Tuple[object, GridSearchCV]:
    """
    Run a grid search over hyperparameters and return best estimator and the GridSearchCV object.
    """
    gs = GridSearchCV(
        estimator=model,
        param_grid=param_grid,
        scoring=scoring,
        cv=cv,
        n_jobs=-1,
    )
    gs.fit(X, y)
    return gs.best_estimator_, gs
