from pathlib import Path
from typing import Optional

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd


def _ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


# ---------- Plots ----------

def plot_distribution(df: pd.DataFrame, column: str, save_dir: Optional[Path] = None):
    """Create a distribution plot (hist + KDE) for a numeric column."""
    plt.figure()
    sns.histplot(df[column].dropna(), kde=True)
    plt.title(f"Distribution of {column}")
    plt.xlabel(column)
    plt.ylabel("Count")
    if save_dir is not None:
        _ensure_dir(save_dir)
        out = save_dir / f"dist_{column}.png"
        plt.savefig(out, bbox_inches="tight")
    plt.close()


def plot_boxplot(df: pd.DataFrame, column: str, save_dir: Optional[Path] = None):
    """Create a boxplot for a numeric column."""
    plt.figure()
    sns.boxplot(y=df[column])
    plt.title(f"Boxplot of {column}")
    if save_dir is not None:
        _ensure_dir(save_dir)
        out = save_dir / f"box_{column}.png"
        plt.savefig(out, bbox_inches="tight")
    plt.close()


def plot_violin(df: pd.DataFrame, column: str, save_dir: Optional[Path] = None):
    """Create a violin plot for a numeric column."""
    plt.figure()
    sns.violinplot(y=df[column])
    plt.title(f"Violin Plot of {column}")
    if save_dir is not None:
        _ensure_dir(save_dir)
        out = save_dir / f"violin_{column}.png"
        plt.savefig(out, bbox_inches="tight")
    plt.close()


# ---------- Outliers ----------

def detect_outliers_iqr(series: pd.Series, factor: float = 1.5):
    """Return a boolean mask where True indicates an outlier using the IQR rule."""
    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1
    lower = q1 - factor * iqr
    upper = q3 + factor * iqr
    return (series < lower) | (series > upper)


def cap_outliers_iqr(series: pd.Series, factor: float = 1.5) -> pd.Series:
    """Cap (winsorize) outliers using the IQR rule."""
    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1
    lower = q1 - factor * iqr
    upper = q3 + factor * iqr
    return series.clip(lower=lower, upper=upper)
