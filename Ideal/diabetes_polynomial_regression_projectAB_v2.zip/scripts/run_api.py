import sys
from pathlib import Path

import uvicorn

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

# FastAPI app lives in src.deployment_api:app
if __name__ == "__main__":
    uvicorn.run("src.deployment_api:app", host="0.0.0.0", port=8000, reload=True)
