import sys
from pathlib import Path

import numpy as np
from sklearn.model_selection import KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from src.config import DATA_PATH, TARGET_COLUMN
from src.data_loading import load_diabetes, split_features_target
from src.imputation import simple_pandas_imputer
from src.baselines import get_baseline_models
from src.model_selection import evaluate_models_cv
from src.model import PolynomialRegressionScratch


def evaluate_polynomial_scratch_cv(X, y, degree: int = 2, cv: int = 5) -> float:
    """Perform K-fold CV RMSE for the custom PolynomialRegressionScratch model."""
    kf = KFold(n_splits=cv, shuffle=True, random_state=42)
    rmses = []

    for train_index, test_index in kf.split(X):
        X_train, X_test = X.iloc[train_index], X.iloc[test_index]
        y_train, y_test = y.iloc[train_index], y.iloc[test_index]

        model = PolynomialRegressionScratch(degree=degree, l2_reg=0.0)
        model.fit(X_train, y_train.values)
        y_pred = model.predict(X_test)
        rmse = np.sqrt(((y_test.values - y_pred) ** 2).mean())
        rmses.append(rmse)

    return float(np.mean(rmses))


def main():
    df = load_diabetes(DATA_PATH)
    df_imputed = simple_pandas_imputer(df, strategy="median")
    X, y = split_features_target(df_imputed, target_column=TARGET_COLUMN)

    # Baseline models wrapped in a scaling pipeline where appropriate
    baselines = get_baseline_models()
    pipeline_models = {}
    for name, model in baselines.items():
        # Linear/Ridge/Lasso benefit from scaling; tree doesn't strictly need it
        if "decision_tree" in name:
            pipeline_models[name] = model
        else:
            pipeline_models[name] = Pipeline([
                ("scaler", StandardScaler()),
                ("model", model),
            ])

    results = evaluate_models_cv(X, y, pipeline_models, cv=5)

    # Evaluate custom polynomial model with CV
    poly_rmse = evaluate_polynomial_scratch_cv(X, y, degree=2, cv=5)
    results["polynomial_scratch_deg2"] = poly_rmse

    print("\n=== Model Comparison via 5-fold CV (RMSE) ===")
    for name, rmse in sorted(results.items(), key=lambda x: x[1]):
        print(f"{name:30s} -> RMSE: {rmse:.4f}")


if __name__ == "__main__":
    main()
