from .base import HookTemplate
from .simple_hook import *