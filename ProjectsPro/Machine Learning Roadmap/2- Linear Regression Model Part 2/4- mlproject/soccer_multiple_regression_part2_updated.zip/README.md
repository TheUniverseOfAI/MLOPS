# EPL Soccer Multiple Linear Regression with Club Encoding (Project 2)

This project is a **template-based conversion** of `regression_part2_.ipynb`.

It builds a **multiple linear regression model** to predict **Score** for EPL players
using:

- Numeric features: `DistanceCovered(InKms)`, `BMI`, `Cost`, `PreviousClubCost`
- One-hot encoded team/club indicators: `CHE`, `MUN`, `LIV` (from the `Club` column)

The project uses the **same generic regression template** as Project 1, with a small
extension to optionally one-hot encode categorical columns via configuration.

## 🔧 What this project does

- Loads `data/raw/EPL_Soccer_MLR_LR.csv`
- One-hot encodes `Club` into `CHE`, `MUN`, `LIV`
- Selects the following feature columns:

  - `DistanceCovered(InKms)`
  - `BMI`
  - `Cost`
  - `PreviousClubCost`
  - `CHE`
  - `MUN`
  - `LIV`

- Uses `Score` as the target
- No target transform (`target_transform: "none"`)
- Splits data into train/test (75% / 25%, `random_state=100`)
- Trains a `LinearRegression` model
- Computes **R²** and **MSE**
- Saves model to: `models/epl_soccer_multiple_regression_part2.joblib`
- Logs to `logs/app.log`

## 📂 Structure

The structure is the same template pattern:

```text
soccer_multiple_regression_part2/
├── configs/
│   └── config.yaml
├── data/
│   └── raw/
│       └── EPL_Soccer_MLR_LR.csv
├── logs/
├── models/
├── notebooks/
│   └── EDA.ipynb
├── src/
│   ├── data/
│   ├── features/
│   ├── models/
│   └── utils/
├── tests/
├── requirements.txt
└── README.md
```

## ▶️ How to run training

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows: .venv\Scripts\activate
pip install -r requirements.txt

python -m src.models.train --config configs/config.yaml
```

This will:

1. Load the dataset
2. One-hot encode `Club` (CHE/LIV/MUN)
3. Select the configured features
4. Train and evaluate a regression model
5. Save the model and write logs

## 🔁 Reuse as Template

For another project with categorical variables, you can:

- Change `dataset_path`
- Update `feature_columns`
- Adjust `target_column`
- Update `categorical_columns` to list any columns to one-hot encode.

The core logic in `src/` remains reusable.



# 📘 Multiple Linear Regression — Educational Overview

This project is part of a beginner-friendly series on regression and focuses on
**Multiple Linear Regression** using a soccer player dataset.

## What Will You Learn?

- What is Multiple Linear Regression?
- General Linear Regression Model
- Matrix representation of the General Linear Regression Model
- Matrix representation of Least Squares
- Types of predictive variables
- F-test
- Coefficient of multiple determination
- Adjusted R-squared
- Scatterplots and their interpretation
- Correlation matrix and how to read it
- Understanding multicollinearity
- ANOVA partitioning
- Diagnostic and remedial measures
- Indicator (dummy) variables
- Model selection criteria:
  - R²
  - Mallows Cp criterion
  - AIC / SBC criteria
  - PRESS criterion
- Building a Multiple Linear Regression model end-to-end

## Project Overview

In the first project of this series, we covered the fundamentals of regression
and implemented a simple linear regression model.

This second project builds on that foundation and introduces **Multiple Linear Regression**, 
which models the relationship between **one target variable** and **two or more independent variables**.

It uses the same soccer player dataset and extends the analysis to:

- Include multiple predictors
- Handle categorical variables via indicator (dummy) variables
- Diagnose multicollinearity and model fit
- Use statistical criteria to compare and select models

It is recommended to review **Project 1: Linear Regression Model in Python for Beginners (Part 1)** 
before working through this multiple regression project.

## Aim

To build a Multiple Linear Regression model in Python and understand the core
concepts, diagnostics, and model selection criteria associated with it.

## Data Description

Dataset: **Soccer Player Dataset**

- Players from multiple clubs
- Around ten features describing physical and performance attributes
- Target variable: **Number of Goals / Score** (as modeled in this project)

## Tech Stack

- **Language:** Python
- **Libraries:** numpy, pandas, statsmodels, seaborn, matplotlib, sklearn, scipy

## Approach Summary

The workflow covered in the educational material includes:

1. Importing required libraries and dataset
2. Exploring correlations between features
3. Plotting correlation graphs and scatterplots
4. Identifying and removing:
   - Weakly correlated predictors
   - Highly multicollinear variables
5. Performing train-test split
6. Fitting a Multiple Linear Regression model
7. Converting categorical variables to dummy/indicator variables
8. Evaluating the model and visualizing results
