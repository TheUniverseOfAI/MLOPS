# EPL Soccer Multiple Linear Regression with Club Encoding (Project 2)

This project is a **template-based conversion** of `regression_part2_.ipynb`.

It builds a **multiple linear regression model** to predict **Score** for EPL players
using:

- Numeric features: `DistanceCovered(InKms)`, `BMI`, `Cost`, `PreviousClubCost`
- One-hot encoded team/club indicators: `CHE`, `MUN`, `LIV` (from the `Club` column)

The project uses the **same generic regression template** as Project 1, with a small
extension to optionally one-hot encode categorical columns via configuration.

## 🔧 What this project does

- Loads `data/raw/EPL_Soccer_MLR_LR.csv`
- One-hot encodes `Club` into `CHE`, `MUN`, `LIV`
- Selects the following feature columns:

  - `DistanceCovered(InKms)`
  - `BMI`
  - `Cost`
  - `PreviousClubCost`
  - `CHE`
  - `MUN`
  - `LIV`

- Uses `Score` as the target
- No target transform (`target_transform: "none"`)
- Splits data into train/test (75% / 25%, `random_state=100`)
- Trains a `LinearRegression` model
- Computes **R²** and **MSE**
- Saves model to: `models/epl_soccer_multiple_regression_part2.joblib`
- Logs to `logs/app.log`

## 📂 Structure

The structure is the same template pattern:

```text
soccer_multiple_regression_part2/
├── configs/
│   └── config.yaml
├── data/
│   └── raw/
│       └── EPL_Soccer_MLR_LR.csv
├── logs/
├── models/
├── notebooks/
│   └── EDA.ipynb
├── src/
│   ├── data/
│   ├── features/
│   ├── models/
│   └── utils/
├── tests/
├── requirements.txt
└── README.md
```

## ▶️ How to run training

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows: .venv\Scripts\activate
pip install -r requirements.txt

python -m src.models.train --config configs/config.yaml
```

This will:

1. Load the dataset
2. One-hot encode `Club` (CHE/LIV/MUN)
3. Select the configured features
4. Train and evaluate a regression model
5. Save the model and write logs

## 🔁 Reuse as Template

For another project with categorical variables, you can:

- Change `dataset_path`
- Update `feature_columns`
- Adjust `target_column`
- Update `categorical_columns` to list any columns to one-hot encode.

The core logic in `src/` remains reusable.



# 📘 Multiple Linear Regression — Educational Overview

This project is part of a beginner-friendly series on regression and focuses on
**Multiple Linear Regression** using a soccer player dataset.

## What Will You Learn?

- What is Multiple Linear Regression?
- General Linear Regression Model
- Matrix representation of the General Linear Regression Model
- Matrix representation of Least Squares
- Types of predictive variables
- F-test
- Coefficient of multiple determination
- Adjusted R-squared
- Scatterplots and their interpretation
- Correlation matrix and how to read it
- Understanding multicollinearity
- ANOVA partitioning
- Diagnostic and remedial measures
- Indicator (dummy) variables
- Model selection criteria:
  - R²
  - Mallows Cp criterion
  - AIC / SBC criteria
  - PRESS criterion
- Building a Multiple Linear Regression model end-to-end

## Project Overview

In the first project of this series, we covered the fundamentals of regression
and implemented a simple linear regression model.

This second project builds on that foundation and introduces **Multiple Linear Regression**, 
which models the relationship between **one target variable** and **two or more independent variables**.

It uses the same soccer player dataset and extends the analysis to:

- Include multiple predictors
- Handle categorical variables via indicator (dummy) variables
- Diagnose multicollinearity and model fit
- Use statistical criteria to compare and select models

It is recommended to review **Project 1: Linear Regression Model in Python for Beginners (Part 1)** 
before working through this multiple regression project.

## Aim

To build a Multiple Linear Regression model in Python and understand the core
concepts, diagnostics, and model selection criteria associated with it.

## Data Description

Dataset: **Soccer Player Dataset**

- Players from multiple clubs
- Around ten features describing physical and performance attributes
- Target variable: **Number of Goals / Score** (as modeled in this project)

## Tech Stack

- **Language:** Python
- **Libraries:** numpy, pandas, statsmodels, seaborn, matplotlib, sklearn, scipy

## Approach Summary

The workflow covered in the educational material includes:

1. Importing required libraries and dataset
2. Exploring correlations between features
3. Plotting correlation graphs and scatterplots
4. Identifying and removing:
   - Weakly correlated predictors
   - Highly multicollinear variables
5. Performing train-test split
6. Fitting a Multiple Linear Regression model
7. Converting categorical variables to dummy/indicator variables
8. Evaluating the model and visualizing results


---

## 🧠 How to Interpret the Diagnostics

Once you run:

```bash
python -m src.models.diagnostics --config configs/config.yaml
```

you will find several files under the `reports/` folder. Here is how to read them:

### 1. `vif.csv` — Variance Inflation Factor

Each row shows a feature and its VIF value:

- **VIF ≈ 1** → no multicollinearity.
- **VIF between 1 and 5** → acceptable; mild correlation.
- **VIF > 5** → potentially problematic multicollinearity.
- **VIF > 10** → serious multicollinearity; consider removing or combining variables.

Use this to decide which predictors are redundant or highly correlated with others.

### 2. `influence.csv` — Cook’s D, Leverage, Standardized Residuals

Each row corresponds to an observation:

- **Cook's distance (`cooks_d`)**  
  - Measures how much an observation influences the fitted model.  
  - Rule of thumb: points with **Cook's D > 4 / n** (n = number of rows) may be influential.

- **Leverage (`leverage`)**  
  - Measures how far an observation's predictors are from the overall mean.  
  - High leverage points can strongly affect the regression line.  
  - Rough rule: leverage > **2p / n** (p = number of predictors + intercept) deserves attention.

- **Standardized residuals (`std_resid`)**  
  - Residuals scaled to have mean 0 and variance ≈ 1.  
  - Values with **|std_resid| > 2** may be outliers; **|std_resid| > 3** are strong candidates.

Together, these help you find **outliers** and **influential points** that might distort your model.

### 3. `anova.csv` — ANOVA Table

The ANOVA table decomposes the variability into:

- **Sum of Squares** (SS) for each source (e.g., model, residuals)
- **Degrees of Freedom** (df)
- **Mean Squares** (MS = SS / df)
- **F-statistic** and **p-value**

Use ANOVA to test whether your overall regression model is statistically significant:

- A **small p-value (e.g., < 0.05)** for the model term indicates that at least one predictor
  is significantly related to the target.

### 4. `ols_summary.txt` — Full OLS Summary

This text report includes:

- Coefficients and standard errors
- t-statistics and p-values for each predictor
- R-squared and Adjusted R-squared
- AIC and BIC
- Other key diagnostics

Use this to interpret:

- Which predictors are statistically significant (p-value < 0.05)
- The direction and magnitude of each effect (sign and size of coefficients)
- Overall model quality (R², adjusted R²)

### 5. `diagnostic_metrics.json` — AIC, BIC, PRESS, DW, Normality & BP Tests

This JSON contains several scalar metrics:

- **`aic`, `bic` (AIC, BIC)**  
  - Lower values indicate better models **relative to each other**.  
  - Use these for **model comparison**, not as absolute scores.

- **`press` (PRESS statistic)**  
  - Sum of squared prediction errors when each observation is left out.  
  - Lower PRESS → better predictive performance / generalization.

- **`durbin_watson` (DW statistic)**  
  - Tests for autocorrelation in residuals.  
  - Range is 0 to 4:  
    - ≈ 2 → little to no autocorrelation (good).  
    - < 1 or > 3 → potential serious autocorrelation problems.

- **Normality test (`normal_ad_stat`, `normal_ad_pvalue`)**  
  - Based on the Anderson–Darling test for residual normality.  
  - **p-value > 0.05** → cannot reject normality (good).  
  - **p-value < 0.05** → residuals deviate from normal; consider transformations or robust methods.

- **Breusch–Pagan test (`bp_*`) for heteroscedasticity**  
  - **`bp_lm_pvalue`** and **`bp_f_pvalue`**:  
    - **p-value > 0.05** → no evidence of heteroscedasticity (good).  
    - **p-value < 0.05** → residual variance is not constant; consider transforming variables or using robust standard errors.

By combining these diagnostics, you can:

- Validate the assumptions of linear regression
- Identify multicollinearity and influential observations
- Compare different model specifications
- Decide whether additional feature engineering or transformations are needed
