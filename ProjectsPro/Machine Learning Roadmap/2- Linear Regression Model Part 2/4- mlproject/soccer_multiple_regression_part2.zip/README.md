# EPL Soccer Multiple Linear Regression with Club Encoding (Project 2)

This project is a **template-based conversion** of `regression_part2_.ipynb`.

It builds a **multiple linear regression model** to predict **Score** for EPL players
using:

- Numeric features: `DistanceCovered(InKms)`, `BMI`, `Cost`, `PreviousClubCost`
- One-hot encoded team/club indicators: `CHE`, `MUN`, `LIV` (from the `Club` column)

The project uses the **same generic regression template** as Project 1, with a small
extension to optionally one-hot encode categorical columns via configuration.

## 🔧 What this project does

- Loads `data/raw/EPL_Soccer_MLR_LR.csv`
- One-hot encodes `Club` into `CHE`, `MUN`, `LIV`
- Selects the following feature columns:

  - `DistanceCovered(InKms)`
  - `BMI`
  - `Cost`
  - `PreviousClubCost`
  - `CHE`
  - `MUN`
  - `LIV`

- Uses `Score` as the target
- No target transform (`target_transform: "none"`)
- Splits data into train/test (75% / 25%, `random_state=100`)
- Trains a `LinearRegression` model
- Computes **R²** and **MSE**
- Saves model to: `models/epl_soccer_multiple_regression_part2.joblib`
- Logs to `logs/app.log`

## 📂 Structure

The structure is the same template pattern:

```text
soccer_multiple_regression_part2/
├── configs/
│   └── config.yaml
├── data/
│   └── raw/
│       └── EPL_Soccer_MLR_LR.csv
├── logs/
├── models/
├── notebooks/
│   └── EDA.ipynb
├── src/
│   ├── data/
│   ├── features/
│   ├── models/
│   └── utils/
├── tests/
├── requirements.txt
└── README.md
```

## ▶️ How to run training

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows: .venv\Scripts\activate
pip install -r requirements.txt

python -m src.models.train --config configs/config.yaml
```

This will:

1. Load the dataset
2. One-hot encode `Club` (CHE/LIV/MUN)
3. Select the configured features
4. Train and evaluate a regression model
5. Save the model and write logs

## 🔁 Reuse as Template

For another project with categorical variables, you can:

- Change `dataset_path`
- Update `feature_columns`
- Adjust `target_column`
- Update `categorical_columns` to list any columns to one-hot encode.

The core logic in `src/` remains reusable.
